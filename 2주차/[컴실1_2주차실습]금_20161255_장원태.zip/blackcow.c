#include "animal.h"
#include <stdio.h>

void func2(){
	printf("This is func2");
}
