#include "animal.h"
#include <stdio.h>
int main(){
	printf("Hello World!\n");

	func1();
	printf("\n");

	func2();
	printf("\n");

	func3();
	printf("\n");

	return 0;
}
