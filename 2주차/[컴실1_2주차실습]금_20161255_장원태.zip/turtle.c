#include "animal.h"
#include <stdio.h>

void func1(){
	printf("This is func1");
}
